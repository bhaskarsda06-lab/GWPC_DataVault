# Corrections applied

1. `sat_policy_details.prior_policy_period_state` was corrected to
   `prior_policy_period_date` because the supplied satellite SQL maps
   `BasedOnDate` to `prior_policy_period_date`.

2. Monetary target columns use `DECIMAL(18,2)`.

3. `insured_legal_name` remains in the target DDL, but no source mapping was
   present in the supplied SQL. The synthetic input therefore does not invent
   a mapping for this field.

4. The synthetic source tables mirror the source table names referenced by the
   supplied Hub, Link and Satellite SQL.

5. The source input is DEV-only synthetic data. It must not be promoted to
   TEST or PROD.

6. The target DDL is a reference/validation artifact. The production target
   tables should be created and evolved through dbt + AutomateDV rather than
   manually running this DDL.
