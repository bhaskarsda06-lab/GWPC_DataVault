# Execution order

## DEV

1. Run `sql/dev_source_ddl.sql`
2. Run `sql/dev_source_input.sql`
3. Run `sql/verify_dev_input.sql`
4. Run `dbt deps`
5. Run staging tests/build
6. Run Hub models
7. Continue with Links and Satellites

## Important

Do not run `sql/dev_source_input.sql` in TEST or PROD.

The corrected target DDL is provided for validation/reference only. In the
production dbt pipeline, target objects should be controlled by dbt and
AutomateDV.
