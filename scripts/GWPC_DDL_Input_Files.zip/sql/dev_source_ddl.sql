-- ============================================================
-- GWPC Synthetic DEV Source DDL
-- These tables emulate the source pc_* / pctl_* tables used by
-- the supplied legacy Hub/Link/Satellite SQL.
-- DEV ONLY - do not execute in TEST/PROD.
-- ============================================================

CREATE CATALOG IF NOT EXISTS autdbt_vault_dev;
CREATE SCHEMA IF NOT EXISTS autdbt_vault_dev.autdbts;

USE CATALOG autdbt_vault_dev;
USE SCHEMA autdbts;

CREATE TABLE IF NOT EXISTS pc_account_curr (
    PublicID STRING,
    AccountNumber STRING,
    Name STRING,
    AddressID BIGINT,
    Retired INT,
    AccountStatus BIGINT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pc_contact_curr (
    PublicID STRING,
    ID BIGINT,
    FirstName STRING,
    MiddleName STRING,
    LastName STRING,
    Name STRING,
    DateOfBirth DATE,
    TaxID STRING,
    EmailAddress1 STRING,
    EmailAddress2 STRING,
    HomePhone STRING,
    CellPhone STRING,
    PrimaryAddressID BIGINT,
    Suffix BIGINT,
    MaritalStatus BIGINT,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pc_policy_curr (
    PublicID STRING,
    PolicyNumber STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pc_policyperiod_curr (
    PublicID STRING,
    PolicyNumber STRING,
    TermNumber INT,
    PolicyID STRING,
    BranchID BIGINT,
    TermType BIGINT,
    NewRenewal STRING,
    EffectiveDate TIMESTAMP,
    ExpirationDate TIMESTAMP,
    Jurisdiction BIGINT,
    BillingMethod BIGINT,
    PaymentPlanSummaryID BIGINT,
    Status BIGINT,
    BasedOnID STRING,
    BasedOnDate TIMESTAMP,
    PeriodID STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pc_policycontactrole_curr (
    PublicID STRING,
    BranchID BIGINT,
    ContactDenorm BIGINT,
    Role BIGINT,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pc_accountcontact_curr (
    AccountID STRING,
    ContactID BIGINT,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pc_accountcontactrole_curr (
    AccountContactID STRING,
    Role BIGINT,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pc_address_curr (
    ID BIGINT,
    AddressLine1 STRING,
    AddressLine2 STRING,
    AddressLine3 STRING,
    City STRING,
    PostalCode STRING,
    State BIGINT,
    Country BIGINT,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pc_effectivedatedfields_curr (
    BranchID BIGINT,
    OfferingCode STRING,
    TransactionStatus BIGINT,
    TransactionPremiumAmount DECIMAL(18,2),
    TransactionCostAmount DECIMAL(18,2),
    TotalCostAmount DECIMAL(18,2),
    TotalCostCurrency STRING,
    TotalPremiumAmount DECIMAL(18,2),
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pc_paymentplansummary_curr (
    ID BIGINT,
    PaymentPlanName STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pctl_accountcontactrole_curr (
    ID BIGINT,
    TYPECODE STRING,
    DESCRIPTION STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pctl_accountstatus_curr (
    ID BIGINT,
    TYPECODE STRING,
    DESCRIPTION STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pctl_state_curr (
    ID BIGINT,
    TYPECODE STRING,
    DESCRIPTION STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pctl_country_curr (
    ID BIGINT,
    TYPECODE STRING,
    DESCRIPTION STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pctl_namesuffix_curr (
    ID BIGINT,
    TYPECODE STRING,
    DESCRIPTION STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pctl_maritalstatus_curr (
    ID BIGINT,
    TYPECODE STRING,
    DESCRIPTION STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pctl_termtype_curr (
    ID BIGINT,
    TYPECODE STRING,
    DESCRIPTION STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pctl_jurisdiction_curr (
    ID BIGINT,
    TYPECODE STRING,
    DESCRIPTION STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pctl_billingmethod_curr (
    ID BIGINT,
    TYPECODE STRING,
    DESCRIPTION STRING,
    Retired INT
) USING DELTA;

CREATE TABLE IF NOT EXISTS pctl_policyperiodstatus_curr (
    ID BIGINT,
    TYPECODE STRING,
    DESCRIPTION STRING,
    Retired INT
) USING DELTA;
