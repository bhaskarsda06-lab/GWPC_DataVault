-- ============================================================
-- GWPC Data Vault 2.0 - Corrected Target DDL
-- DEV reference / validation DDL
-- Target: autdbt_vault_dev.autdbts
-- NOTE: In production, dbt + AutomateDV should own target creation.
-- ============================================================

CREATE CATALOG IF NOT EXISTS autdbt_vault_dev;
CREATE SCHEMA IF NOT EXISTS autdbt_vault_dev.autdbts;

USE CATALOG autdbt_vault_dev;
USE SCHEMA autdbts;

CREATE TABLE IF NOT EXISTS hub_account (
    account_hk STRING NOT NULL,
    source_system_unique_identifier STRING NOT NULL,
    account_number STRING NOT NULL,
    source_system_name STRING NOT NULL,
    load_dts TIMESTAMP NOT NULL
) USING DELTA;

CREATE TABLE IF NOT EXISTS sat_account_core (
    account_hk STRING NOT NULL,
    account_name STRING,
    account_address STRING,
    account_city STRING,
    account_state_code STRING,
    account_country_code STRING,
    account_postal_code STRING,
    load_dts TIMESTAMP NOT NULL,
    hashdiff STRING NOT NULL
) USING DELTA;

CREATE TABLE IF NOT EXISTS sat_account_status (
    account_hk STRING NOT NULL,
    account_status_code STRING,
    load_dts TIMESTAMP NOT NULL,
    hashdiff STRING NOT NULL
) USING DELTA;

CREATE TABLE IF NOT EXISTS hub_contact (
    contact_hk STRING NOT NULL,
    source_system_contact_identifier STRING NOT NULL,
    source_system_unique_identifier STRING NOT NULL,
    source_system_name STRING NOT NULL,
    load_dts TIMESTAMP NOT NULL
) USING DELTA;

CREATE TABLE IF NOT EXISTS sat_contact_details (
    contact_hk STRING NOT NULL,
    first_name STRING,
    middle_name STRING,
    last_name STRING,
    contact_name STRING,
    birth_dt DATE,
    tax_id STRING,
    email STRING,
    email_2 STRING,
    home_phone STRING,
    cell_phone STRING,
    contact_address_line_1 STRING,
    contact_address_line_2 STRING,
    contact_address_line_3 STRING,
    city STRING,
    postal_code STRING,
    state_code STRING,
    country_code STRING,
    name_suffix_code STRING,
    marital_status_code STRING,
    load_dts TIMESTAMP NOT NULL,
    hashdiff STRING NOT NULL
) USING DELTA;

CREATE TABLE IF NOT EXISTS link_policy_contact (
    policy_contact_hk STRING NOT NULL,
    policy_hk STRING NOT NULL,
    contact_hk STRING NOT NULL,
    load_dts TIMESTAMP NOT NULL,
    source_system_name STRING NOT NULL
) USING DELTA;

CREATE TABLE IF NOT EXISTS hub_policy (
    policy_hk STRING NOT NULL,
    source_system_unique_identifier STRING NOT NULL,
    policy_number STRING NOT NULL,
    term_number STRING NOT NULL,
    source_system_name STRING NOT NULL,
    load_dts TIMESTAMP NOT NULL
) USING DELTA;

CREATE TABLE IF NOT EXISTS sat_policy_details (
    policy_hk STRING NOT NULL,
    policy_term_type_code STRING,
    new_renewal_indicator STRING,
    policy_effective_ts TIMESTAMP,
    policy_expiration_ts TIMESTAMP,
    policy_base_state_code STRING,
    billing_method_code STRING,
    payment_plan_name STRING,
    product_offering_code STRING,
    transaction_status_code STRING,
    insured_legal_name STRING,
    policy_transaction_premium_amount DECIMAL(18,2),
    policy_transaction_cost_amount DECIMAL(18,2),
    policy_total_cost_amount DECIMAL(18,2),
    policy_total_cost_currency_code STRING,
    total_premium_amount DECIMAL(18,2),
    prior_policy_period_id STRING,
    prior_policy_period_date TIMESTAMP,
    policy_period_id STRING,
    load_dts TIMESTAMP NOT NULL,
    hashdiff STRING NOT NULL
) USING DELTA;
