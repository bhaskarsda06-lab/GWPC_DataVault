-- ============================================================
-- GWPC Synthetic DEV Source Input
-- DEV ONLY
-- ============================================================

USE CATALOG autdbt_vault_dev;
USE SCHEMA autdbts;

-- Clear synthetic DEV source data for repeatable runs.
DELETE FROM pc_account_curr;
DELETE FROM pc_contact_curr;
DELETE FROM pc_policy_curr;
DELETE FROM pc_policyperiod_curr;
DELETE FROM pc_policycontactrole_curr;
DELETE FROM pc_accountcontact_curr;
DELETE FROM pc_accountcontactrole_curr;
DELETE FROM pc_address_curr;
DELETE FROM pc_effectivedatedfields_curr;
DELETE FROM pc_paymentplansummary_curr;
DELETE FROM pctl_accountcontactrole_curr;
DELETE FROM pctl_accountstatus_curr;
DELETE FROM pctl_state_curr;
DELETE FROM pctl_country_curr;
DELETE FROM pctl_namesuffix_curr;
DELETE FROM pctl_maritalstatus_curr;
DELETE FROM pctl_termtype_curr;
DELETE FROM pctl_jurisdiction_curr;
DELETE FROM pctl_billingmethod_curr;
DELETE FROM pctl_policyperiodstatus_curr;

-- Accounts
INSERT INTO pc_account_curr VALUES
('A000001','ACC10001','ABC Manufacturing',1001,0,1),
('A000002','ACC10002','Blue Horizon LLC',1002,0,1),
('A000003','ACC10003','Cedar Retail Inc',1003,0,2);

-- Contacts
INSERT INTO pc_contact_curr VALUES
('C000101',101,'John','A','Smith','John A Smith',DATE '1985-04-12','TAX100101',
 'john.smith@example.com','john.alt@example.com','555-100-1001','555-200-1001',
 1001,1,1,0),
('C000102',102,'Mary','B','Johnson','Mary B Johnson',DATE '1990-08-22','TAX100102',
 'mary.johnson@example.com',NULL,'555-100-1002','555-200-1002',
 1002,2,2,0),
('C000103',103,'Robert',NULL,'Williams','Robert Williams',DATE '1978-11-03','TAX100103',
 'robert.williams@example.com',NULL,'555-100-1003','555-200-1003',
 1003,1,1,0);

-- Policies
INSERT INTO pc_policy_curr VALUES
('POL001','GWPC-10001',0),
('POL002','GWPC-10002',0),
('POL003','GWPC-10003',0);

-- Policy periods
INSERT INTO pc_policyperiod_curr VALUES
('PP000001','GWPC-10001',1,'POL001',50001,1,'New',
 TIMESTAMP '2026-01-01 00:00:00',TIMESTAMP '2026-12-31 23:59:59',
 1,1,9001,1,NULL,NULL,'PERIOD-10001',0),
('PP000002','GWPC-10002',2,'POL002',50002,2,'Renewal',
 TIMESTAMP '2026-02-01 00:00:00',TIMESTAMP '2027-01-31 23:59:59',
 2,2,9002,1,'PP000001',TIMESTAMP '2026-01-01 00:00:00','PERIOD-10002',0),
('PP000003','GWPC-10003',1,'POL003',50003,1,'New',
 TIMESTAMP '2026-03-01 00:00:00',TIMESTAMP '2027-02-28 23:59:59',
 3,1,9003,1,NULL,NULL,'PERIOD-10003',0);

-- Policy contact roles
INSERT INTO pc_policycontactrole_curr VALUES
('PCR000001',50001,101,10,0),
('PCR000002',50002,102,10,0),
('PCR000003',50003,103,10,0);

-- Account-contact relationships
INSERT INTO pc_accountcontact_curr VALUES
('ACCTCONTACT001',101,0),
('ACCTCONTACT002',102,0),
('ACCTCONTACT003',103,0);

INSERT INTO pc_accountcontactrole_curr VALUES
('ACCTCONTACT001',10,0),
('ACCTCONTACT002',10,0),
('ACCTCONTACT003',10,0);

-- Addresses
INSERT INTO pc_address_curr VALUES
(1001,'100 Main Street','Suite 100',NULL,'Los Angeles','90001',1,1,0),
(1002,'200 Market Street',NULL,NULL,'New York','10001',2,1,0),
(1003,'300 Congress Avenue','Floor 2',NULL,'Austin','73301',3,1,0);

-- Effective-dated policy values
INSERT INTO pc_effectivedatedfields_curr VALUES
(50001,'COMMERCIAL_STD',1,12500.00,350.00,12850.00,'USD',12500.00,0),
(50002,'COMMERCIAL_PREM',1,15000.00,400.00,15400.00,'USD',15000.00,0),
(50003,'SMB_STANDARD',1,9000.00,250.00,9250.00,'USD',9000.00,0);

-- Payment plans
INSERT INTO pc_paymentplansummary_curr VALUES
(9001,'Annual',0),
(9002,'Monthly',0),
(9003,'Quarterly',0);

-- Reference tables
INSERT INTO pctl_accountcontactrole_curr VALUES
(10,'AccountHolder','Account Holder',0);

INSERT INTO pctl_accountstatus_curr VALUES
(1,'Active','Active',0),
(2,'Inactive','Inactive',0);

INSERT INTO pctl_state_curr VALUES
(1,'CA','California',0),
(2,'NY','New York',0),
(3,'TX','Texas',0);

INSERT INTO pctl_country_curr VALUES
(1,'US','United States',0);

INSERT INTO pctl_namesuffix_curr VALUES
(1,'JR','Junior',0),
(2,'SR','Senior',0);

INSERT INTO pctl_maritalstatus_curr VALUES
(1,'M','Married',0),
(2,'S','Single',0);

INSERT INTO pctl_termtype_curr VALUES
(1,'ANNUAL','Annual',0),
(2,'MULTI_TERM','Multi Term',0);

INSERT INTO pctl_jurisdiction_curr VALUES
(1,'CA','California',0),
(2,'NY','New York',0),
(3,'TX','Texas',0);

INSERT INTO pctl_billingmethod_curr VALUES
(1,'DIRECT','Direct Bill',0),
(2,'AGENCY','Agency Bill',0);

INSERT INTO pctl_policyperiodstatus_curr VALUES
(1,'BOUND','Bound',0);
