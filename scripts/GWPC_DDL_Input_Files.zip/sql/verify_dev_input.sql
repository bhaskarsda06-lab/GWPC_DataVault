-- ============================================================
-- Verify corrected DEV source input
-- ============================================================

USE CATALOG autdbt_vault_dev;
USE SCHEMA autdbts;

SELECT 'pc_account_curr' AS table_name, COUNT(*) AS row_count FROM pc_account_curr
UNION ALL SELECT 'pc_contact_curr', COUNT(*) FROM pc_contact_curr
UNION ALL SELECT 'pc_policy_curr', COUNT(*) FROM pc_policy_curr
UNION ALL SELECT 'pc_policyperiod_curr', COUNT(*) FROM pc_policyperiod_curr
UNION ALL SELECT 'pc_policycontactrole_curr', COUNT(*) FROM pc_policycontactrole_curr
UNION ALL SELECT 'pc_accountcontact_curr', COUNT(*) FROM pc_accountcontact_curr
UNION ALL SELECT 'pc_accountcontactrole_curr', COUNT(*) FROM pc_accountcontactrole_curr
UNION ALL SELECT 'pc_address_curr', COUNT(*) FROM pc_address_curr
UNION ALL SELECT 'pc_effectivedatedfields_curr', COUNT(*) FROM pc_effectivedatedfields_curr
UNION ALL SELECT 'pc_paymentplansummary_curr', COUNT(*) FROM pc_paymentplansummary_curr
UNION ALL SELECT 'pctl_accountcontactrole_curr', COUNT(*) FROM pctl_accountcontactrole_curr
UNION ALL SELECT 'pctl_accountstatus_curr', COUNT(*) FROM pctl_accountstatus_curr
UNION ALL SELECT 'pctl_state_curr', COUNT(*) FROM pctl_state_curr
UNION ALL SELECT 'pctl_country_curr', COUNT(*) FROM pctl_country_curr
UNION ALL SELECT 'pctl_namesuffix_curr', COUNT(*) FROM pctl_namesuffix_curr
UNION ALL SELECT 'pctl_maritalstatus_curr', COUNT(*) FROM pctl_maritalstatus_curr
UNION ALL SELECT 'pctl_termtype_curr', COUNT(*) FROM pctl_termtype_curr
UNION ALL SELECT 'pctl_jurisdiction_curr', COUNT(*) FROM pctl_jurisdiction_curr
UNION ALL SELECT 'pctl_billingmethod_curr', COUNT(*) FROM pctl_billingmethod_curr
UNION ALL SELECT 'pctl_policyperiodstatus_curr', COUNT(*) FROM pctl_policyperiodstatus_curr
ORDER BY table_name;

SELECT PublicID, AccountNumber, Name, Retired FROM pc_account_curr ORDER BY PublicID;
SELECT PublicID, ID, FirstName, LastName, Retired FROM pc_contact_curr ORDER BY ID;
SELECT PublicID, PolicyNumber, TermNumber, BranchID, BasedOnID, BasedOnDate
FROM pc_policyperiod_curr ORDER BY PublicID;
